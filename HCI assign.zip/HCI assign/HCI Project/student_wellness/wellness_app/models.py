from django.db import models

# Create your models here.from django.db import models

class Task(models.Model):
    PRIORITY_CHOICES = [
        ('high', 'High'),
        ('medium', 'Medium'),
        ('low', 'Low'),
    ]

    title = models.CharField(max_length=200)
    due_date = models.DateField()
    completed = models.BooleanField(default=False)
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    #estimated_time = models.FloatField(default=1.0, null=True, blank=True)  # Default time is 1 hour


    def __str__(self):
        return self.title

        

    
