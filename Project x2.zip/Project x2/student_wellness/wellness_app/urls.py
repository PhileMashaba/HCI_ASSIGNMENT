from django.urls import path
from .views import create_task, list_tasks, complete_task, delete_task, dashboard, signup_view
from django.contrib.auth import views as auth_views

app_name = 'wellness_app'

urlpatterns = [
    path('tasks/', list_tasks, name='list_tasks'),
    path('create_task/', create_task, name='create_task'),
    path('complete-task/<int:task_id>/', complete_task, name='complete_task'),  # Added trailing slash
    path('delete-task/<int:task_id>/', delete_task, name='delete_task'),
    path('dashboard/', dashboard, name='dashboard'),
    path('signup/', signup_view, name='signup'),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
     path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
]
