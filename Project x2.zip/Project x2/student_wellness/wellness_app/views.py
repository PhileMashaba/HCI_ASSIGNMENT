from django.shortcuts import render, redirect, get_object_or_404
from django.utils.timezone import localdate
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.urls import reverse
from .models import Task
from .forms import TaskForm, SignUpForm, LoginForm

# Create a new task (only accessible for logged-in users)
@login_required
def create_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.user = request.user  # Link task to logged-in user
            task.save()
            return redirect('wellness_app:list_tasks')
    else:
        form = TaskForm()

    return render(request, 'create_task.html', {
        'form': form,
        'style_url': '/static/css/styles.css'
    })

# List tasks for the logged-in user
@login_required
def list_tasks(request):
    tasks = Task.objects.filter(user=request.user)
    today = localdate()
    return render(request, 'task_list.html', {
        'tasks': tasks,
        'today': today,
        'style_url': '/static/css/styles.css'
    })

# Mark a task as completed
@login_required
def complete_task(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    task.completed = True
    task.save()
    return redirect('wellness_app:list_tasks')

# Delete a task
@login_required
def delete_task(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    task.delete()
    return redirect('wellness_app:list_tasks')

# Dashboard view (only logged-in users can see this)
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.utils.timezone import localdate
from .models import Task

@login_required
def dashboard(request):
    today = localdate()
    tasks = Task.objects.filter(user=request.user)

    total = tasks.count()
    completed = tasks.filter(completed=True).count()
    pending = tasks.filter(completed=False).count()
    overdue = tasks.filter(due_date__lt=today, completed=False).count()

    context = {
        'total_tasks': total or 1,  # avoid division by zero
        'completed_tasks': completed,
        'pending_tasks': pending,
        'overdue_tasks': overdue,
        'today': today,
         'user_first_name': request.user.first_name or "User",
    }

    return render(request, 'dashboard.html', context)


# Sign-up view (allows users to create an account and log in immediately)
def signup_view(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()  # Create the user
            login(request, user)  # Log the user in after signing up
            return redirect('wellness_app:dashboard')  # Redirect to dashboard after sign-up
    else:
        form = SignUpForm()

    return render(request, 'signup.html', {'form': form})

# Login view (user enters their credentials to log in)
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                next_url = request.GET.get('next', reverse('wellness_app:dashboard'))  # Default to dashboard if no next
                return redirect(next_url)
            else:
                form.add_error(None, "Invalid username or password.")  # Add error if login fails
    else:
        form = LoginForm()

    return render(request, 'login.html', {'form': form})

