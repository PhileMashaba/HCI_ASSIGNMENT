from django.shortcuts import render, redirect
from .models import Task
from django.utils.timezone import localdate
from .forms import TaskForm
from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect

# Create your views here.


def create_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            print(f"Saving Task: {task.title}, Priority: {task.priority}")  # Debugging output
            task.save()
            return redirect('wellness_app:list_tasks')  # Redirect after saving
        else:
            print("Form is invalid:", form.errors)  # Debugging output

    else:
        form = TaskForm()
        
    return render(request, 'create_task.html', {'form': form, 'style_url': '/static/css/styles.css'})


def list_tasks(request):
    tasks = Task.objects.all()
    today = localdate()
    return render(request, 'task_list.html', {'tasks': tasks, 'today': today,'style_url': '/static/css/styles.css'})    


def complete_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    task.completed =True
    task.save()
    return redirect('wellness_app:list_tasks')

def delete_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    task.delete()
    return redirect('wellness_app:list_tasks')

from django.shortcuts import render
from django.utils.timezone import localdate
from .models import Task

def dashboard(request):
    tasks = Task.objects.all()
    today = localdate()

    total_tasks = tasks.count()
    completed_tasks = tasks.filter(completed=True).count()
    pending_tasks = tasks.filter(completed=False).count()
    overdue_tasks = tasks.filter(due_date__lt=today, completed=False).count()

    context = {
        'total_tasks': total_tasks,
        'completed_tasks': completed_tasks,
        'pending_tasks': pending_tasks,
        'overdue_tasks': overdue_tasks,
        'today': today
    }
    return render(request, 'dashboard.html', context)

