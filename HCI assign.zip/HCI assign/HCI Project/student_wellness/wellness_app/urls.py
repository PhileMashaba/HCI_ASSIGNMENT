from django.urls import path
from .views import create_task, list_tasks, complete_task, delete_task, dashboard 

app_name = 'wellness_app'

urlpatterns= [
    path('tasks/', list_tasks, name='list_tasks'),
    path('create_task/', create_task, name='create_task'),
    path('complete-task/<int:task_id>', complete_task, name= 'complete_task'),
    path('delete-task/<int:task_id>/', delete_task, name='delete_task'),
    path('dashboard/', dashboard, name= 'dashboard')

]